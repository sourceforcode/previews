// --- Config Start --- //
var katamscookieTitle = "Website Cookies."; // Title
var katamscookieDesc = "This website uses cookies. By using this website you consent to our use of these cookies. For more information visit our "; // Description
var katamscookieLink = '<a href="page/privacy-policy" target="_blank">Privacy Policy</a>'; // Cookie Privacy policy link
var katamscookieButton = "I Agree"; // Button text
// ---  Config End      --- //


function katamsFadeIn(elem, display){
  var el = document.getElementById(elem);
  el.style.opacity = 0;
  el.style.display = display || "block";

  (function fade() {
    var val = parseFloat(el.style.opacity);
    if (!((val += .02) > 1)) {
      el.style.opacity = val;
      requestAnimationFrame(fade);
    }
  })();
};
function katamsFadeOut(elem){
  var el = document.getElementById(elem);
  el.style.opacity = 1;

  (function fade() {
    if ((el.style.opacity -= .02) < 0) {
      el.style.display = "none";
    } else {
      requestAnimationFrame(fade);
    }
  })();
};

function setCookie(name,value,days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days*24*60*60*1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
}
function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}
function eraseCookie(name) {   
    document.cookie = name+'=; Max-Age=-99999999;';  
}

function cookieConsent() {
  if (!getCookie('katamscookieDismiss')) {
    document.body.innerHTML += '<div class="cookieConsentContainer" id="cookieConsentContainer"><div class="cookieTitle"><a>' + katamscookieTitle + '</a></div><div class="cookieDesc"><p>' + katamscookieDesc + ' ' + katamscookieLink + '</p></div><div class="cookieButton"><a onClick="katamscookieDismiss();">' + katamscookieButton + '</a></div></div>';
	katamsFadeIn("cookieConsentContainer");
  }
}

function katamscookieDismiss() {
  setCookie('katamscookieDismiss','1',7);
  katamsFadeOut("cookieConsentContainer");
}

window.onload = function() { cookieConsent(); };